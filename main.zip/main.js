// main.js

App.showCenterLabel("Hello world");